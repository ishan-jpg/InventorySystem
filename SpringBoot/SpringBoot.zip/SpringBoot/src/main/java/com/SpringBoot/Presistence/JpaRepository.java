package com.SpringBoot.Presistence;

public interface JpaRepository<T, T1> {
}
